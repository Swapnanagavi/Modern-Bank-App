let balance = 0; // initial balance
let hasDeposited=false;
let hasWithdrawn=false;

function depositMoney() {
  let amount = parseFloat(document.getElementById("depositAmount").value);
  let message = document.getElementById("message");

  if (isNaN(amount) || amount <= 0) {
    message.style.color = "red";
    message.textContent = "Please enter a valid deposit amount!";
    return;
  }

  balance += amount;
  document.getElementById("balance").textContent = balance.toFixed(2);
  message.style.color = "green";
  message.textContent = `Successfully Deposited ₹${amount}`;
  document.getElementById("depositAmount").value = "";
  hasDeposited=true;
  if(hasDeposited && hasWithdrawn){
    message.textContent+="Thanks for Visiting";
  }
} 

function withdrawMoney() {
  let amount = parseFloat(document.getElementById("withdrawAmount").value);
  let message = document.getElementById("message");

  if (isNaN(amount) || amount <= 0) {
    message.style.color = "red";
    message.textContent = "Please enter a valid withdraw amount!";
    return;
  }

  if (amount > balance) {
    message.style.color = "red";
    message.textContent = "Insufficient balance!";
    return;
  }

  balance -= amount;
  document.getElementById("balance").textContent = balance.toFixed(2);
  message.style.color = "green";
  message.textContent = `Successfully withdrawn ₹${amount}`;
  document.getElementById("withdrawAmount").value = "";
  hasWithdrawn=true;
  if(hasDeposited && hasWithdrawn){
    message.innerHTML+= "<br>Thanks for Visiting";
  }
}

function cancelOperation() {
  document.getElementById("depositAmount").value = "";
  document.getElementById("withdrawAmount").value = "";
  let message = document.getElementById("message");
  message.textContent = "";

  // Reset flags so message will show only after new deposit and withdraw operations
  hasDeposited = false;
  hasWithdrawn = false;
}


